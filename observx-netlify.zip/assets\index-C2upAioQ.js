import"https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm";(function(){const a=document.createElement("link").relList;if(a&&a.supports&&a.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))i(o);new MutationObserver(o=>{for(const s of o)if(s.type==="childList")for(const l of s.addedNodes)l.tagName==="LINK"&&l.rel==="modulepreload"&&i(l)}).observe(document,{childList:!0,subtree:!0});function t(o){const s={};return o.integrity&&(s.integrity=o.integrity),o.referrerPolicy&&(s.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?s.credentials="include":o.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function i(o){if(o.ep)return;o.ep=!0;const s=t(o);fetch(o.href,s)}})();console.log("🔄 ObservX v2.0 - Loading with force refresh...");let L=null;let n=null,g=null;const M=e=>{const a=document.getElementById("page-loader");a&&(a.style.display=e?"flex":"none")},Y=()=>{const e=document.createElement("div");e.id="page-loader",e.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0.9);
    display: none;
    justify-content: center;
    align-items: center;
    z-index: 9999;
    backdrop-filter: blur(5px);
  `,e.innerHTML=`
    <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
      <span class="visually-hidden">Loading...</span>
    </div>
  `,document.body.appendChild(e)},z=()=>{const e=()=>{document.querySelectorAll(".animate-on-scroll").forEach(t=>{const i=t.getBoundingClientRect().top,o=window.innerHeight;i<o-100&&(t.classList.add("fade-in-up"),t.style.opacity="1")})};e(),window.addEventListener("scroll",e)},G=()=>{const e=document.getElementById("mainNav");e&&window.addEventListener("scroll",()=>{window.scrollY>50?e.classList.add("scrolled"):e.classList.remove("scrolled")})},D=()=>{[].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]')).map(function(a){return new bootstrap.Tooltip(a)})},J=()=>{Y(),z(),G(),D()};function k(e,a,t=4e3){const i="global-notifications";let o=document.getElementById(i);o||(o=document.createElement("div"),o.id=i,o.style.position="fixed",o.style.top="1rem",o.style.right="1rem",o.style.zIndex="1060",document.body.appendChild(o));const s=document.createElement("div");s.className=`alert alert-${e} alert-dismissible fade show`,s.role="alert",s.innerHTML=`${a} <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>`,o.appendChild(s),t>0&&setTimeout(()=>{try{bootstrap.Alert.getOrCreateInstance(s).close()}catch{s.remove()}},t)}const N={home:X,about:W,contact:K,"user-login":Z,"police-login":ee,"user-register":Q,"user-dashboard":se,"user-dashboard-enhanced":()=>window.location.href="user_dashboard_enhanced.html","police-dashboard":U,"file-complaint":ie,"emergency-complaint":ae,"view-complaint":ce,"my-complaints":oe,"view-complaints":de,"update-complaint":me};window.addEventListener("hashchange",()=>{const e=location.hash.slice(2)||"home";H(e)});document.addEventListener("DOMContentLoaded",async()=>{try{M(!0),await V();const e=location.hash.slice(2)||"home";await H(e),J()}catch(e){console.error("Error initializing app:",e),k("error","Failed to initialize the application. Please try again.")}finally{M(!1)}});async function V(){if(!L)try{const a=await(await fetch("http://localhost:8080/check_auth.php",{method:"GET",headers:{Accept:"application/json"},mode:"cors"})).json();return a.authenticated&&a.user?(n=a.user,g=a.user.role||"user",F(),!0):!1}catch(e){return console.log("Auth check error:",e),!1}try{const{data:e,error:a}=await L.auth.getSession();if(a)throw a;if(e.session){if(n=e.session.user,L){const{data:t,error:i}=await L.from("users").select("role, full_name, avatar_url").eq("id",n.id).maybeSingle();if(i)throw i;g=(t==null?void 0:t.role)||"user",n={...n,...t}}else g="user";if(F(),userData!=null&&userData.avatar_url){const t=document.getElementById("user-avatar");t&&(t.src=userData.avatar_url,t.alt=userData.full_name||"User",t.style.display="block")}return!0}return!1}catch(e){return console.error("Authentication error:",e),k("error","Failed to check authentication status"),!1}}function F(){const e=document.getElementById("authMenu");e&&(n?e.innerHTML=`
      <div class="dropdown">
        <a class="d-flex align-items-center text-decoration-none dropdown-toggle" 
           href="#" 
           role="button" 
           data-bs-toggle="dropdown" 
           aria-expanded="false"
           data-bs-offset="10,20">
          <img id="user-avatar" 
               src="${n.avatar_url||"https://ui-avatars.com/api/?name="+encodeURIComponent(n.email||"U")+"&background=2563eb&color=fff"}" 
               alt="${n.full_name||"User"}" 
               class="rounded-circle me-2" 
               style="width: 36px; height: 36px; object-fit: cover; display: ${n.avatar_url?"block":"none"};">
          <span class="d-none d-md-inline">${n.full_name||n.email||"User"}</span>
        </a>
        <ul class="dropdown-menu dropdown-menu-end shadow" style="min-width: 200px;">
          <li>
            <div class="dropdown-header d-flex align-items-center">
              <img id="user-avatar-menu" 
                   src="${n.avatar_url||"https://ui-avatars.com/api/?name="+encodeURIComponent(n.email||"U")+"&background=2563eb&color=fff"}" 
                   alt="${n.full_name||"User"}" 
                   class="rounded-circle me-2" 
                   style="width: 40px; height: 40px; object-fit: cover;">
              <div>
                <h6 class="mb-0">${n.full_name||"User"}</h6>
                <small class="text-muted">${n.email||""}</small>
              </div>
            </div>
          </li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item" href="#/user-dashboard"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a></li>
          <li><a class="dropdown-item" href="#/my-profile"><i class="bi bi-person me-2"></i>My Profile</a></li>
          <li><a class="dropdown-item" href="#/settings"><i class="bi bi-gear me-2"></i>Settings</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item text-danger" href="#" onclick="logout()"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
        </ul>
      </div>
    `:e.innerHTML=`
      <div class="d-flex gap-2">
        <a href="#/user-register" class="btn btn-outline-primary d-none d-md-inline-flex">
          <i class="bi bi-person-plus me-1"></i> Register
        </a>
        <div class="dropdown">
          <button class="btn btn-primary px-3" type="button" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="bi bi-box-arrow-in-right me-1"></i> Login
          </button>
          <ul class="dropdown-menu dropdown-menu-end shadow" style="min-width: 200px;">
            <li><a class="dropdown-item" href="#/user-login"><i class="bi bi-person me-2"></i>User Login</a></li>
            <li><a class="dropdown-item" href="#/police-login"><i class="bi bi-shield-lock me-2"></i>Police Login</a></li>
          </ul>
        </div>
      </div>
    `,D())}async function H(e){const a=document.getElementById("page-content");if(a)try{if(M(!0),a.style.opacity="0",a.style.transition="opacity 0.3s ease",await new Promise(t=>setTimeout(t,200)),N[e]){if(a.innerHTML=await N[e](),a.style.opacity="0",a.style.animation="fadeIn 0.5s forwards",e==="file-complaint"){const t=document.getElementById("captureUserLocation");t&&t.addEventListener("click",async i=>{i.preventDefault(),t.disabled=!0,t.innerHTML='<div class="spinner-border spinner-border-sm" role="status"></div> Capturing...';try{const o=await te(),s=`${o.latitude.toFixed(6)}, ${o.longitude.toFixed(6)} (±${o.accuracy.toFixed(0)}m)`;document.getElementById("userLocation").value=s,document.getElementById("userLocation").setAttribute("data-location",JSON.stringify(o)),k("success","Location captured successfully!",3e3)}catch(o){k("error",`Error: ${o.message}`,5e3)}finally{t.disabled=!1,t.innerHTML='<i class="bi bi-geo-alt"></i> Capture'}})}if(e==="emergency-complaint"){const t=document.getElementById("capturePhotoLocation");t&&t.addEventListener("click",async i=>{i.preventDefault(),t.disabled=!0,t.innerHTML='<div class="spinner-border spinner-border-sm" role="status"></div> Capturing...';try{const o=await new Promise((d,b)=>{navigator.geolocation.getCurrentPosition(d,b,{enableHighAccuracy:!0,timeout:1e4,maximumAge:0})}),{latitude:s,longitude:l}=o.coords,r=document.getElementById("photoLocation");r.value=`${s.toFixed(6)}, ${l.toFixed(6)}`,r.setAttribute("data-location",JSON.stringify({lat:s,lng:l,captured_at:new Date().toISOString()})),t.innerHTML='<i class="bi bi-check-circle"></i> Captured',t.classList.remove("btn-danger"),t.classList.add("btn-success"),setTimeout(()=>{t.disabled=!1,t.innerHTML='<i class="bi bi-camera"></i> Capture',t.classList.remove("btn-success"),t.classList.add("btn-danger")},2e3)}catch(o){console.error("Photo location capture failed:",o),t.innerHTML='<i class="bi bi-x-circle"></i> Failed',t.classList.remove("btn-danger"),t.classList.add("btn-outline-danger"),setTimeout(()=>{t.disabled=!1,t.innerHTML='<i class="bi bi-camera"></i> Capture',t.classList.remove("btn-outline-danger"),t.classList.add("btn-danger")},2e3)}})}}else a.innerHTML=`
        <div class="container py-5 text-center">
          <div class="error-404">
            <h1 class="display-1 text-primary">404</h1>
            <h2 class="mb-4">Page Not Found</h2>
            <p class="lead mb-4">The page you are looking for doesn't exist or has been moved.</p>
            <a href="#/" class="btn btn-primary">
              <i class="bi bi-house-door me-2"></i>Back to Home
            </a>
          </div>
        </div>
      `;D(),window.scrollTo({top:0,behavior:"smooth"})}catch(t){console.error(`Error loading page ${e}:`,t),k("error","Failed to load the page. Please try again.")}finally{M(!1),a.style.opacity="1"}}function X(){return`
    <div class="container">
      <div class="hero-section">
        <div style="display: flex; align-items: center; justify-content: center; margin-bottom: 1rem;">
          <img src="https://img.freepik.com/premium-vector/eye-logo-vector-design_9999-14585.jpg" alt="ObservX" style="height: 80px; width: 80px; border-radius: 50%; object-fit: cover; margin-right: 1.5rem; background: white; padding: 5px; box-shadow: 0 4px 12px rgba(0,0,0,0.2);">
          <h1 style="margin: 0; font-size: 3.5rem;">ObservX</h1>
        </div>
        <p class="tagline">A Digital Platform for Public Safety & Justice</p>
        <p class="mb-4">File complaints securely and track their status in real-time</p>
        ${n?`
          <a href="#/file-complaint" class="btn btn-light btn-lg me-2">File Complaint</a>
          <a href="#/my-complaints" class="btn btn-outline-light btn-lg">View Status</a>
        `:`
          <a href="#/user-register" class="btn btn-light btn-lg me-2">Register Now</a>
          <a href="#/user-login" class="btn btn-outline-light btn-lg">Login</a>
        `}
      </div>

      <div class="row g-4 mb-5">
        <div class="col-md-4">
          <div class="feature-box">
            <i class="bi bi-file-text"></i>
            <h3>Easy Complaint Filing</h3>
            <p>File complaints with detailed information and evidence</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="feature-box">
            <i class="bi bi-shield-lock"></i>
            <h3>Secure & Confidential</h3>
            <p>Your information is protected with government-level security</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="feature-box">
            <i class="bi bi-clock-history"></i>
            <h3>Real-time Tracking</h3>
            <p>Track the status of your complaint instantly</p>
          </div>
        </div>
      </div>

      <div class="row g-4">
        <div class="col-md-6">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><i class="bi bi-info-circle"></i> For Citizens</h5>
              <p class="card-text">Register and file complaints for various incidents including theft, cyber crimes, and missing persons.</p>
              ${n?"":'<a href="#/user-register" class="btn btn-sm btn-primary">Get Started</a>'}
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><i class="bi bi-building"></i> For Police</h5>
              <p class="card-text">Login to view all complaints filed by citizens and manage investigations efficiently.</p>
              <a href="#/police-login" class="btn btn-sm btn-primary">Police Login</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  `}function W(){return`
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <div class="text-center mb-4">
            <img src="https://img.freepik.com/premium-vector/eye-logo-vector-design_9999-14585.jpg" alt="ObservX" style="height: 80px; margin-bottom: 1rem;">
          </div>
          <h1>About ObservX</h1>
          <p class="lead">ObservX is a national digital platform designed to bridge the gap between citizens and law enforcement agencies.</p>

          <h3>Our Mission</h3>
          <p>To provide a secure, transparent, and efficient system for filing and tracking police complaints across India.</p>

          <h3>Key Features</h3>
          <ul class="list-group list-group-flush mb-4">
            <li class="list-group-item"><i class="bi bi-check-circle text-success"></i> 24/7 complaint filing availability</li>
            <li class="list-group-item"><i class="bi bi-check-circle text-success"></i> Anonymous complaint option</li>
            <li class="list-group-item"><i class="bi bi-check-circle text-success"></i> Evidence upload support</li>
            <li class="list-group-item"><i class="bi bi-check-circle text-success"></i> Real-time status updates</li>
            <li class="list-group-item"><i class="bi bi-check-circle text-success"></i> Police officer assignment tracking</li>
            <li class="list-group-item"><i class="bi bi-check-circle text-success"></i> Secure data encryption</li>
          </ul>

          <h3>Complaint Categories</h3>
          <div class="row g-3">
            <div class="col-md-6">
              <strong>Theft & Property Crimes</strong>
              <p class="text-muted small">Burglary, theft, robbery, auto theft</p>
            </div>
            <div class="col-md-6">
              <strong>Cyber Crimes</strong>
              <p class="text-muted small">Online fraud, hacking, phishing</p>
            </div>
            <div class="col-md-6">
              <strong>Missing Persons</strong>
              <p class="text-muted small">Missing adult, missing child, runaway</p>
            </div>
            <div class="col-md-6">
              <strong>Violence & Harassment</strong>
              <p class="text-muted small">Assault, harassment, threats</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  `}function K(){return`
    <div class="container">
      <div class="row">
        <div class="col-lg-6 mx-auto">
          <h1>Contact Us</h1>

          <div class="alert alert-info">
            <strong>Emergency?</strong> Call 100 or your local police station immediately.
          </div>

          <div class="card mb-3">
            <div class="card-body">
              <h5 class="card-title"><i class="bi bi-telephone"></i> Helpline</h5>
              <p class="card-text">1800-200-SECURE (7323873)</p>
              <small class="text-muted">Available 24/7</small>
            </div>
          </div>

          <div class="card mb-3">
            <div class="card-body">
              <h5 class="card-title"><i class="bi bi-envelope"></i> Email</h5>
              <p class="card-text">support@secureindiapolice.gov.in</p>
            </div>
          </div>

          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><i class="bi bi-building"></i> Address</h5>
              <p class="card-text">
                Ministry of Public Safety & Justice<br>
                Government of India<br>
                New Delhi - 110001
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  `}function Q(){return n?'<div class="alert alert-warning text-center mt-5">You are already logged in. <a href="#/user-dashboard">Go to Dashboard</a></div>':`
    <div class="login-container">
      <div class="login-card">
        <h2><i class="bi bi-person-plus"></i> Register as Citizen</h2>
        <form id="registerForm">
          <div class="mb-3">
            <label class="form-label">Full Name</label>
            <input type="text" class="form-control" name="fullName" id="fullName" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" class="form-control" name="email" id="email" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Mobile Number</label>
            <input type="tel" class="form-control" name="mobile" id="mobile" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Address</label>
            <textarea class="form-control" name="address" id="address" rows="2"></textarea>
          </div>
          <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" class="form-control" name="password" id="password" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Confirm Password</label>
            <input type="password" class="form-control" name="password2" id="confirmPassword" required>
          </div>
          <div id="registerAlert"></div>
          <button type="submit" class="btn btn-primary w-100">Register</button>
        </form>
        <p class="text-center mt-3">Already have an account? <a href="#/user-login">Login here</a></p>
      </div>
    </div>
  `}function Z(){return n?'<div class="alert alert-warning text-center mt-5">You are already logged in. <a href="#/user-dashboard">Go to Dashboard</a></div>':`
    <div class="container mt-5">
      <div class="row justify-content-center">
        <div class="col-md-6 col-lg-4">
          <div class="card shadow">
            <div class="card-body p-4">
              <div class="text-center mb-4">
                <div class="badge bg-success text-white p-2 mb-3">
                  <i class="bi bi-person-check me-2"></i>CITIZEN LOGIN
                </div>
                <h3 class="card-title">Welcome Back</h3>
                <p class="text-muted small">Login to file and track complaints</p>
              </div>
              
              <form id="loginForm">
                <div class="mb-3">
                  <label for="loginEmail" class="form-label">Email Address</label>
                  <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                    <input type="email" class="form-control" id="loginEmail" placeholder="Enter your email" required>
                  </div>
                </div>
                
                <div class="mb-3">
                  <label for="loginPassword" class="form-label">Password</label>
                  <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                    <input type="password" class="form-control" id="loginPassword" placeholder="Enter your password" required>
                  </div>
                </div>
                
                <div id="loginAlert"></div>
                
                <div class="d-grid">
                  <button type="submit" class="btn btn-success btn-lg">
                    <i class="bi bi-box-arrow-in-right me-2"></i>Login
                  </button>
                </div>
              </form>
              
              <div class="text-center mt-4 pt-3 border-top">
                <p class="mb-2">Don't have an account? <a href="#/user-register" class="text-decoration-none">Register here</a></p>
                <p class="mb-0"><small>Police Officer? <a href="#/police-login" class="text-decoration-none">Login here</a></small></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `}function ee(){return n&&g==="police"?'<div class="alert alert-warning text-center mt-5">You are already logged in. <a href="#/police-dashboard">Go to Dashboard</a></div>':`
    <div class="container mt-5">
      <div class="row justify-content-center">
        <div class="col-md-6 col-lg-4">
          <div class="card shadow">
            <div class="card-body p-4">
              <div class="text-center mb-4">
                <div class="badge bg-primary text-white p-2 mb-3">
                  <i class="bi bi-shield-lock me-2"></i>POLICE PORTAL
                </div>
                <h3 class="card-title">Police Admin Login</h3>
                <p class="text-muted small">Authorized personnel only</p>
              </div>
              
              <div class="alert alert-info mb-3">
                <small><i class="bi bi-info-circle me-2"></i>This portal is exclusively for authorized police officers only.</small>
              </div>
              
              <div class="alert alert-success mb-3">
                <small><strong><i class="bi bi-key me-2"></i>Test Credentials:</strong><br>
                📧 Email: police@observx.com<br>
                🔑 Password: police123</small>
              </div>
              
              <form id="policeLoginForm">
                <div class="mb-3">
                  <label for="policeEmail" class="form-label">Police Email ID</label>
                  <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                    <input type="email" class="form-control" id="policeEmail" placeholder="police@observx.com" value="police@observx.com" required>
                  </div>
                </div>
                
                <div class="mb-3">
                  <label for="policePassword" class="form-label">Password</label>
                  <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                    <input type="password" class="form-control" id="policePassword" placeholder="police123" value="police123" required>
                  </div>
                </div>
                
                <div id="policeLoginAlert"></div>
                
                <div class="d-grid">
                  <button type="submit" class="btn btn-primary btn-lg">
                    <i class="bi bi-shield-check me-2"></i>Login to Portal
                  </button>
                </div>
              </form>
              
              <div class="text-center mt-4 pt-3 border-top">
                <p class="text-muted small mb-0">For access issues, contact your administrator</p>
                <p class="mb-0"><a href="#/" class="text-decoration-none">← Back to Home</a></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `}async function te(){return new Promise((e,a)=>{if(!navigator.geolocation){a(new Error("Geolocation is not supported by this browser"));return}navigator.geolocation.getCurrentPosition(t=>{const{latitude:i,longitude:o,accuracy:s}=t.coords;e({latitude:i,longitude:o,accuracy:s,timestamp:new Date().toISOString()})},t=>{a(t)},{enableHighAccuracy:!0,timeout:1e4,maximumAge:0})})}function ie(){return`
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <div class="form-section">
            <div class="text-center mb-4">
              <div class="btn-group" role="group">
                <a href="#/file-complaint" class="btn btn-outline-primary active">
                  <i class="bi bi-file-earmark-text"></i> Normal Complaint
                </a>
                <a href="#/emergency-complaint" class="btn btn-outline-danger">
                  <i class="bi bi-exclamation-triangle-fill"></i> Emergency Complaint
                </a>
              </div>
            </div>
            
            <h2><i class="bi bi-file-earmark-text"></i> File a Normal Complaint</h2>
            <p class="text-muted">For non-urgent complaints that will be processed within 24-48 hours</p>
            
            <form id="complaintForm">
              <div class="mb-3">
                <label class="form-label">Complaint Title <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="complaintTitle" placeholder="Brief title of your complaint" required>
              </div>
              <div class="mb-3">
                <label class="form-label">Category <span class="text-danger">*</span></label>
                <select class="form-select" id="category" required>
                  <option value="">Select a category</option>
                  <option value="theft">Theft & Robbery</option>
                  <option value="cyber-crime">Cyber Crime</option>
                  <option value="missing-person">Missing Person</option>
                  <option value="violence">Violence & Harassment</option>
                  <option value="fraud">Fraud & Forgery</option>
                  <option value="property">Property Damage</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div class="mb-3">
                <label class="form-label">Incident Date <span class="text-danger">*</span></label>
                <input type="date" class="form-control" id="incidentDate" required>
              </div>
              <div class="mb-3">
                <label class="form-label">Your Current Location (Auto-captured) <span class="text-danger">*</span></label>
                <div class="input-group">
                  <input type="text" class="form-control" id="userLocation" placeholder="Waiting for GPS..." readonly>
                  <button class="btn btn-outline-secondary" type="button" id="captureUserLocation">
                    <i class="bi bi-geo-alt"></i> Capture
                  </button>
                </div>
                <small class="text-muted">Your current location will be recorded for verification</small>
              </div>
              <div class="mb-3">
                <label class="form-label">Crime Location (Where incident happened) <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="crimeLocation" placeholder="Address or location of incident" required>
                <small class="text-muted">Optional: Provide GPS coordinates (latitude, longitude)</small>
              </div>
              <div class="mb-3">
                <label class="form-label">Description <span class="text-danger">*</span></label>
                <textarea class="form-control" id="description" rows="5" placeholder="Provide detailed information about the incident" required></textarea>
              </div>
              <div class="mb-3">
                <label class="form-label">Upload Evidence (Optional)</label>
                <input type="file" class="form-control" id="evidenceFile" accept=".pdf,.jpg,.jpeg,.png,.mp4,.gif">
                <small class="text-muted">Accepted: PDF, JPG, PNG, MP4, GIF (Max 10MB)</small>
              </div>
              <div id="complaintAlert"></div>
              <button type="submit" class="btn btn-primary w-100">
                <i class="bi bi-file-earmark-plus"></i> Submit Normal Complaint
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  `}function ae(){return`
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <div class="form-section emergency-section">
            <div class="alert alert-danger d-flex align-items-center mb-4">
              <i class="bi bi-exclamation-triangle-fill me-3 fs-4"></i>
              <div>
                <strong>EMERGENCY COMPLAINT</strong>
                <div class="small">For urgent matters requiring immediate police attention</div>
              </div>
            </div>
            
            <div class="text-center mb-4">
              <div class="btn-group" role="group">
                <a href="#/file-complaint" class="btn btn-outline-primary">
                  <i class="bi bi-file-earmark-text"></i> Normal Complaint
                </a>
                <a href="#/emergency-complaint" class="btn btn-outline-danger active">
                  <i class="bi bi-exclamation-triangle-fill"></i> Emergency Complaint
                </a>
              </div>
            </div>
            
            <h2 class="text-danger"><i class="bi bi-exclamation-triangle-fill"></i> File an Emergency Complaint</h2>
            <p class="text-danger fw-bold">This will be prioritized for immediate action</p>
            
            <form id="emergencyComplaintForm">
              <div class="row g-3">
                <div class="col-md-6">
                  <div class="mb-3">
                    <label class="form-label">Emergency Type <span class="text-danger">*</span></label>
                    <select class="form-select border-danger" id="emergencyType" required>
                      <option value="">Select emergency type</option>
                      <option value="life-threatening">Life Threatening</option>
                      <option value="crime-in-progress">Crime in Progress</option>
                      <option value="accident">Serious Accident</option>
                      <option value="fire">Fire Emergency</option>
                      <option value="medical-emergency">Medical Emergency</option>
                      <option value="missing-child">Missing Child</option>
                      <option value="domestic-violence">Domestic Violence</option>
                      <option value="other-emergency">Other Emergency</option>
                    </select>
                  </div>
                </div>
                
                <div class="col-md-6">
                  <div class="mb-3">
                    <label class="form-label">Urgency Level <span class="text-danger">*</span></label>
                    <div class="btn-group w-100" role="group">
                      <input type="radio" class="btn-check" name="urgency" id="urgency-critical" value="critical" required>
                      <label class="btn btn-outline-danger" for="urgency-critical">
                        <i class="bi bi-exclamation-triangle"></i> Critical
                      </label>
                      
                      <input type="radio" class="btn-check" name="urgency" id="urgency-high" value="high" required>
                      <label class="btn btn-outline-warning" for="urgency-high">
                        <i class="bi bi-exclamation-circle"></i> High
                      </label>
                      
                      <input type="radio" class="btn-check" name="urgency" id="urgency-medium" value="medium" required>
                      <label class="btn btn-outline-info" for="urgency-medium">
                        <i class="bi bi-info-circle"></i> Medium
                      </label>
                    </div>
                  </div>
                </div>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Emergency Title <span class="text-danger">*</span></label>
                <input type="text" class="form-control border-danger" id="emergencyTitle" placeholder="Brief description of emergency" required>
              </div>
              
              <div class="row g-3">
                <div class="col-md-6">
                  <div class="mb-3">
                    <label class="form-label">Photo Location <span class="text-danger">*</span></label>
                    <div class="input-group">
                      <input type="text" class="form-control border-danger" id="photoLocation" placeholder="Where photo was taken" required>
                      <button class="btn btn-danger" type="button" id="capturePhotoLocation">
                        <i class="bi bi-camera"></i> Capture
                      </button>
                    </div>
                    <small class="text-danger">Location where the photo/evidence was captured</small>
                  </div>
                </div>
                
                <div class="col-md-6">
                  <div class="mb-3">
                    <label class="form-label">Upload Photo <span class="text-danger">*</span></label>
                    <input type="file" class="form-control border-danger" id="emergencyPhoto" accept="image/*" required>
                    <small class="text-danger">Photo evidence is required for emergency complaints</small>
                  </div>
                </div>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Emergency Description <span class="text-danger">*</span></label>
                <textarea class="form-control border-danger" id="emergencyDescription" rows="3" placeholder="Describe the emergency situation in detail" required></textarea>
              </div>
              
              <div class="row g-3">
                <div class="col-md-6">
                  <div class="mb-3">
                    <label class="form-label">Contact Number <span class="text-danger">*</span></label>
                    <input type="tel" class="form-control border-danger" id="emergencyContact" placeholder="Your mobile number" required>
                  </div>
                </div>
                
                <div class="col-md-6">
                  <div class="mb-3">
                    <label class="form-label">Your Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control border-danger" id="emergencyName" placeholder="Your full name" required>
                  </div>
                </div>
              </div>
              
              <div class="mb-3">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" id="confirmEmergency" required>
                  <label class="form-check-label text-danger" for="confirmEmergency">
                    I confirm this is a genuine emergency requiring immediate police attention
                  </label>
                </div>
              </div>
              
              <div id="emergencyComplaintAlert"></div>
              
              <button type="submit" class="btn btn-danger w-100 btn-lg">
                <i class="bi bi-exclamation-triangle-fill"></i> Submit Emergency Complaint
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  `}function se(){return`
    <div class="container">
      <div class="dashboard-header d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2>Welcome, ${(n||{email:"test@example.com"}).email}</h2>
          <p class="mb-0">Citizen Dashboard</p>
        </div>
        <div>
          <a href="#/emergency-complaint" class="btn btn-danger btn-lg me-2">
            <i class="bi bi-exclamation-triangle-fill"></i> Emergency Complaint
          </a>
          <a href="#/file-complaint" class="btn btn-primary btn-lg">
            <i class="bi bi-file-earmark-plus"></i> Normal Complaint
          </a>
        </div>
      </div>

      <!-- Quick Actions Section -->
      <div class="row mb-4">
        <div class="col-12">
          <div class="card border-0 bg-light">
            <div class="card-body">
              <h5 class="card-title"><i class="bi bi-lightning"></i> Quick Actions</h5>
              <div class="row g-3">
                <div class="col-md-6">
                  <div class="d-grid">
                    <a href="#/emergency-complaint" class="btn btn-danger">
                      <i class="bi bi-exclamation-triangle-fill me-2"></i>
                      <strong>File Emergency Complaint</strong>
                      <div class="small">For urgent matters requiring immediate attention</div>
                    </a>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="d-grid">
                    <a href="#/file-complaint" class="btn btn-primary">
                      <i class="bi bi-file-earmark-plus me-2"></i>
                      <strong>File Normal Complaint</strong>
                      <div class="small">For non-urgent complaints (24-48 hour processing)</div>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row g-3 mb-4">
        <div class="col-md-6">
          <div class="stat-box">
            <div class="number" id="totalComplaints">-</div>
            <div class="label">Total Complaints</div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="stat-box">
            <div class="number" id="resolvedCount">-</div>
            <div class="label">Resolved</div>
          </div>
        </div>
      </div>

      <h3 class="mb-3">Your Recent Complaints</h3>
      <div id="complaintsContainer" class="mb-4">
        <div class="loading">
          <div class="spinner-border" role="status"></div>
        </div>
      </div>

      <div class="text-center">
        <a href="#/my-complaints" class="btn btn-outline-primary">View All Complaints</a>
      </div>
    </div>
  `}function oe(){if(console.log("renderMyComplaints called"),g==="police")return'<div class="container mt-5"><div class="alert alert-danger">Unauthorized access.</div></div>';const e=`
    <div class="container">
      <h2 class="mb-4"><i class="bi bi-file-text"></i> My Complaints</h2>

      <div class="mb-3">
        <input type="text" class="form-control" id="searchInput" placeholder="Search by complaint ID or title...">
      </div>

      <div id="myComplaintsContainer">
        <div class="loading">
          <div class="spinner-border" role="status"></div>
        </div>
      </div>
    </div>
  `;return console.log("Returning HTML for My Complaints"),setTimeout(()=>{console.log("Loading complaints..."),console.log("Current user:",n),console.log("Current role:",g),le();const a=document.getElementById("searchInput");a&&a.addEventListener("input",t=>{const i=t.target.value.toLowerCase();ne(i)})},500),e}let _=[];async function le(){const e=document.getElementById("myComplaintsContainer");if(e)try{const t=await(await fetch("http://localhost:8080/get_complaints.php",{method:"GET",headers:{Accept:"application/json"},mode:"cors"})).json();if(!t.success)throw new Error(t.message||"Failed to load complaints");_=t.complaints,$(_)}catch(a){console.error("Error loading complaints:",a),e.innerHTML=`<div class="alert alert-danger">Failed to load complaints: ${a.message}</div>`}}function ne(e){if(!e){$(_);return}const a=_.filter(t=>t.title.toLowerCase().includes(e)||t.complaint_id.toLowerCase().includes(e)||t.category.toLowerCase().includes(e));$(a)}function $(e){const a=document.getElementById("myComplaintsContainer");if(!a)return;if(e.length===0){a.innerHTML=`
      <div class="alert alert-info text-center">
        <i class="bi bi-info-circle"></i> No complaints found. 
        <a href="#/file-complaint" class="btn btn-primary btn-sm ms-2">File Your First Complaint</a>
      </div>
    `;return}const t=e.map(i=>`
    <div class="card mb-3">
      <div class="card-body">
        <div class="row">
          <div class="col-md-8">
            <h5 class="card-title">${i.title}</h5>
            <p class="card-text">${i.description.substring(0,100)}${i.description.length>100?"...":""}</p>
            <div class="mb-2">
              <span class="badge bg-${re(i.status)}">${i.status}</span>
              <span class="badge bg-secondary ms-2">${i.category}</span>
            </div>
          </div>
          <div class="col-md-4 text-end">
            <div class="text-muted small">
              <div><strong>ID:</strong> ${i.complaint_id}</div>
              <div><strong>Date:</strong> ${new Date(i.created_at).toLocaleDateString()}</div>
            </div>
            <button class="btn btn-outline-primary btn-sm mt-2" onclick="viewComplaint('${i.complaint_id}')">
              <i class="bi bi-eye"></i> View
            </button>
          </div>
        </div>
      </div>
    </div>
  `).join("");a.innerHTML=t}function re(e){switch(e.toLowerCase()){case"pending":return"warning";case"under_investigation":return"info";case"resolved":return"success";case"closed":return"secondary";default:return"secondary"}}window.viewComplaint=function(e){location.hash=`#/view-complaint?id=${e}`};function U(){return!n||g!=="police"?'<div class="container mt-5"><div class="alert alert-danger">Unauthorized access. <a href="#/police-login">Police Login</a></div></div>':`
    <div class="container">
      <div class="dashboard-header">
        <h2>Police Dashboard</h2>
        <p class="mb-0">Officer ID: ${n.email}</p>
      </div>

      <div class="row g-3 mb-4">
        <div class="col-md-3">
          <div class="stat-box">
            <div class="number" id="pendingCount">-</div>
            <div class="label">Pending</div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="stat-box">
            <div class="number" id="investigatingCount">-</div>
            <div class="label">Investigating</div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="stat-box">
            <div class="number" id="resolvedCount2">-</div>
            <div class="label">Resolved</div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="stat-box">
            <div class="number" id="totalComplaints2">-</div>
            <div class="label">Total</div>
          </div>
        </div>
      </div>

      <div class="row mb-3">
        <div class="col-md-4">
          <label class="form-label">Filter by Status</label>
          <select class="form-select" id="statusFilter">
            <option value="">All Status</option>
            <option value="pending">Pending</option>
            <option value="investigating">Under Investigation</option>
            <option value="resolved">Resolved</option>
          </select>
        </div>
        <div class="col-md-4">
          <label class="form-label">Filter by Category</label>
          <select class="form-select" id="categoryFilter">
            <option value="">All Categories</option>
            <option value="theft">Theft & Robbery</option>
            <option value="cyber-crime">Cyber Crime</option>
            <option value="missing-person">Missing Person</option>
            <option value="violence">Violence & Harassment</option>
            <option value="fraud">Fraud & Forgery</option>
            <option value="property">Property Damage</option>
          </select>
        </div>
        <div class="col-md-4">
          <label class="form-label">&nbsp;</label>
          <button class="btn btn-primary w-100" onclick="loadComplaints()">Apply Filters</button>
        </div>
      </div>

      <h3 class="mb-3">All Complaints</h3>
      <div id="complaintsTableContainer">
        <div class="loading">
          <div class="spinner-border" role="status"></div>
        </div>
      </div>
    </div>
  `}function ce(){return new URLSearchParams(window.location.search).get("id")||""?`
    <div class="container">
      <a href="javascript:history.back()" class="btn btn-outline-secondary mb-3">
        <i class="bi bi-arrow-left"></i> Back
      </a>
      <div id="complaintDetailContainer">
        <div class="loading">
          <div class="spinner-border" role="status"></div>
        </div>
      </div>
    </div>
  `:'<div class="container mt-5"><div class="alert alert-danger">No complaint ID provided.</div></div>'}function de(){return!n||g!=="police"?'<div class="container mt-5"><div class="alert alert-danger">Unauthorized access.</div></div>':U()}function me(){return!n||g!=="police"?'<div class="container mt-5"><div class="alert alert-danger">Unauthorized access.</div></div>':(new URLSearchParams(location.hash).get("id"),`
    <div class="container">
      <a href="javascript:history.back()" class="btn btn-outline-secondary mb-3">
        <i class="bi bi-arrow-left"></i> Back
      </a>

      <div class="form-section">
        <h2>Update Complaint Status</h2>
        <form id="updateComplaintForm">
          <div class="mb-3">
            <label class="form-label">New Status <span class="text-danger">*</span></label>
            <select class="form-select" id="updateStatus" required>
              <option value="">Select Status</option>
              <option value="pending">Pending</option>
              <option value="investigating">Under Investigation</option>
              <option value="resolved">Resolved</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Police Remarks</label>
            <textarea class="form-control" id="policeRemarks" rows="4" placeholder="Add remarks about the complaint"></textarea>
          </div>
          <div id="updateAlert"></div>
          <button type="submit" class="btn btn-primary">Update Status</button>
        </form>
      </div>
    </div>
  `)}document.addEventListener("submit",async e=>{const a=e.target;a.id==="registerForm"?(e.preventDefault(),await pe(a)):a.id==="loginForm"?(e.preventDefault(),await ue()):a.id==="policeLoginForm"?(e.preventDefault(),await ge()):a.id==="complaintForm"?(e.preventDefault(),await ve(a)):a.id==="emergencyComplaintForm"?(e.preventDefault(),await be(a)):a.id==="updateComplaintForm"&&(e.preventDefault(),await fe())});async function pe(e){var d,b,v,u,I;const a=((d=document.getElementById("fullName"))==null?void 0:d.value)||"",t=((b=document.getElementById("email"))==null?void 0:b.value)||"",i=((v=document.getElementById("mobile"))==null?void 0:v.value)||"",o=((u=document.getElementById("address"))==null?void 0:u.value)||"",s=((I=document.getElementById("password"))==null?void 0:I.value)||"",l=document.getElementById("password2")?document.getElementById("password2").value:document.getElementById("confirmPassword")?document.getElementById("confirmPassword").value:"",r=document.getElementById("registerAlert");if(!a||!t||!i||!s){r.innerHTML='<div class="alert alert-danger">Please fill in all required fields</div>';return}if(s!==l){r.innerHTML='<div class="alert alert-danger">Passwords do not match</div>';return}try{const f=new URLSearchParams;f.append("email",t),f.append("password",s),f.append("password2",l),f.append("fullName",a),f.append("mobile",i),f.append("address",o);const P=[],h=[];h.push("http://localhost:8080/register.php"),h.push("http://127.0.0.1:8080/register.php"),h.push("http://localhost/register.php"),h.push("http://127.0.0.1/register.php");let T=null,E=!1;for(const x of h)if(!P.includes(x)){P.push(x),console.log("Attempting registration POST to",x);try{const C=await fetch(x,{method:"POST",headers:{Accept:"application/json","Content-Type":"application/x-www-form-urlencoded"},body:f,mode:"cors"}),w=await C.text();console.log("Raw response from",x,w);try{const p=JSON.parse(w);if(!C.ok||!p.success){r.innerHTML=`<div class="alert alert-danger">${p.message||"Registration failed"}</div>`,E=!0;break}r.innerHTML='<div class="alert alert-success">Registration successful! Redirecting to login...</div>',e.reset(),setTimeout(()=>{window.location.hash="#/user-login"},2e3),E=!0;break}catch{r.innerHTML=`<div class="alert alert-danger">Server error: ${w}</div>`,E=!0;break}}catch(C){console.warn("Fetch to",x,"failed:",C),T=C;continue}}E||(r.innerHTML=`<div class="alert alert-danger">${T?T.message:"Failed to reach server"}</div>`)}catch(f){r.innerHTML=`<div class="alert alert-danger">${f.message}</div>`}}async function ue(e){var o,s;const a=((o=document.getElementById("loginEmail"))==null?void 0:o.value)||"",t=((s=document.getElementById("loginPassword"))==null?void 0:s.value)||"",i=document.getElementById("loginAlert");if(!a||!t){i.innerHTML='<div class="alert alert-danger">Please fill in all required fields</div>';return}try{const l=new URLSearchParams;l.append("email",a),l.append("password",t);const r=["http://localhost:8080/login.php","http://127.0.0.1:8080/login.php","http://localhost/login.php","http://127.0.0.1/login.php"];let d=!1;for(const b of r)try{const v=await fetch(b,{method:"POST",headers:{Accept:"application/json","Content-Type":"application/x-www-form-urlencoded"},body:l,mode:"cors"}),u=await v.json();if(!v.ok||!u.success){i.innerHTML=`<div class="alert alert-danger">${u.message||"Login failed"}</div>`,d=!0;break}i.innerHTML='<div class="alert alert-success">Login successful! Redirecting...</div>',n={email:a,role:"user"},g="user",F(),setTimeout(()=>{location.hash="#/user-dashboard"},500),d=!0;break}catch(v){console.warn("Login attempt to",b,"failed:",v);continue}d||(i.innerHTML='<div class="alert alert-danger">All login attempts failed</div>')}catch(l){i.innerHTML=`<div class="alert alert-danger">${l.message}</div>`}}async function ge(e){var o,s;const a=((o=document.getElementById("policeEmail"))==null?void 0:o.value)||"",t=((s=document.getElementById("policePassword"))==null?void 0:s.value)||"",i=document.getElementById("policeLoginAlert");if(!a||!t){i.innerHTML='<div class="alert alert-danger">Please fill in all required fields</div>';return}try{const l=new URLSearchParams;l.append("email",a),l.append("password",t);const r=await fetch("http://localhost:8080/police-login.php",{method:"POST",headers:{Accept:"application/json","Content-Type":"application/x-www-form-urlencoded"},body:l,mode:"cors"}),d=await r.json();if(!r.ok||!d.success){i.innerHTML=`<div class="alert alert-danger">${d.message||"Login failed"}</div>`;return}i.innerHTML='<div class="alert alert-success">Login successful! Redirecting...</div>',n={email:a,role:"police"},g="police",F(),setTimeout(()=>{location.hash="#/police-dashboard"},500)}catch(l){i.innerHTML=`<div class="alert alert-danger">${l.message}</div>`}}async function ve(e){var d,b,v,u,I,f,P;const a=((d=document.getElementById("complaintTitle"))==null?void 0:d.value)||"",t=((b=document.getElementById("category"))==null?void 0:b.value)||"",i=((v=document.getElementById("incidentDate"))==null?void 0:v.value)||"",o=document.getElementById("userLocation"),s=((u=document.getElementById("crimeLocation"))==null?void 0:u.value)||"",l=((I=document.getElementById("description"))==null?void 0:I.value)||"";(f=document.getElementById("evidenceFile"))==null||f.files[0];const r=document.getElementById("complaintAlert");try{if(!a||!t||!i||!s||!l)throw new Error("Please fill in all required fields");let h=null;const T=o.getAttribute("data-location");if(T)try{h=JSON.parse(T)}catch{console.warn("Invalid location format, continuing without location")}else h={lat:19.076,lng:72.8777,address:"Mumbai, Maharashtra"};const E={address:s,captured_at:new Date().toISOString()},x={title:a,category:t,incident_date:i,user_location:h,crime_location:E,description:l};console.log("Submitting complaint:",x);const C=(P=document.getElementById("evidenceFile"))==null?void 0:P.files[0];let w;if(C){const c=new FormData;c.append("evidence",C),c.append("title",a),c.append("category",t),c.append("incident_date",i),c.append("user_location",h),c.append("crime_location",E),c.append("description",l),w=await fetch("http://localhost:8080/file_complaint.php",{method:"POST",body:c,mode:"cors"})}else w=await fetch("http://localhost:8080/file_complaint.php",{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify(x),mode:"cors"});console.log("Response status:",w.status),console.log("Response headers:",w.headers);const p=await w.text();console.log("Raw response:",p);let m;try{m=JSON.parse(p)}catch(c){throw console.error("JSON parse error:",c),new Error("Server returned invalid response: "+p)}if(!m.success)throw new Error(m.message||"Failed to file complaint");let S=`<div class="alert alert-success">
      Complaint filed successfully!<br>
      <strong>Complaint ID:</strong> ${m.complaint_id}<br>
      <small>Your location has been recorded for verification</small>`;m.evidence_file&&(S+=`<br><strong>Evidence File:</strong> ${m.evidence_file}<br>
      <small>File uploaded successfully</small>`),S+="</div>",r.innerHTML=S;try{e.reset()}catch(c){console.warn("Form reset failed:",c)}try{const c=document.getElementById("userLocation");c&&(c.value="",c.removeAttribute("data-location"))}catch(c){console.warn("User location field reset failed:",c)}setTimeout(()=>{location.hash="#/my-complaints"},2e3)}catch(h){r.innerHTML=`<div class="alert alert-danger">${h.message}</div>`}}async function be(e){var u,I,f,P,h,T,E,x,C;const a=((u=document.getElementById("emergencyType"))==null?void 0:u.value)||"",t=((I=document.querySelector('input[name="urgency"]:checked'))==null?void 0:I.value)||"",i=((f=document.getElementById("emergencyTitle"))==null?void 0:f.value)||"",o=((P=document.getElementById("photoLocation"))==null?void 0:P.value)||"",s=(h=document.getElementById("emergencyPhoto"))==null?void 0:h.files[0],l=((T=document.getElementById("emergencyDescription"))==null?void 0:T.value)||"",r=((E=document.getElementById("emergencyContact"))==null?void 0:E.value)||"",d=((x=document.getElementById("emergencyName"))==null?void 0:x.value)||"",b=((C=document.getElementById("confirmEmergency"))==null?void 0:C.checked)||!1,v=document.getElementById("emergencyComplaintAlert");try{if(!b)throw new Error("Please confirm this is a genuine emergency");if(!a||!t||!i||!o||!l||!r||!d)throw new Error("Please fill in all required fields");const w={address:o,captured_at:new Date().toISOString()},p={title:`[EMERGENCY] ${i}`,category:a,incident_date:new Date().toISOString().split("T")[0],photo_location:w,description:`EMERGENCY TYPE: ${a}
URGENCY: ${t}
CONTACT: ${r}
NAME: ${d}

${l}`,emergency_type:a,urgency_level:t,contact_number:r,name:d,is_emergency:!0};console.log("Submitting emergency complaint:",p);const m=new FormData;m.append("title",p.title),m.append("category",p.category),m.append("incident_date",p.incident_date),m.append("photo_location",JSON.stringify(p.photo_location)),m.append("description",p.description),m.append("emergency_type",p.emergency_type),m.append("urgency_level",p.urgency_level),m.append("contact_number",p.contact_number),m.append("name",p.name),m.append("is_emergency",p.is_emergency),m.append("user_id",(n==null?void 0:n.id)||"anonymous"),s&&m.append("evidence_file",s);const S=await fetch("http://localhost:8080/file_complaint.php",{method:"POST",body:m,mode:"cors"});if(!S.ok)throw new Error(`HTTP error! status: ${S.status}`);const c=await S.text();console.log("Raw response:",c);let B;try{B=JSON.parse(c)}catch(y){throw console.error("JSON parse error:",y),new Error("Server returned invalid response: "+c)}if(!B.success)throw new Error(B.message||"Failed to file emergency complaint");let A=`<div class="alert alert-success alert-dismissible">
      <strong><i class="bi bi-check-circle-fill"></i> Emergency Complaint Filed Successfully!</strong><br>
      <strong>Complaint ID:</strong> ${B.complaint_id}<br>
      <strong>Priority:</strong> ${t==null?void 0:t.toUpperCase()}<br>
      <small>Your emergency complaint has been marked for immediate attention.<br>
      Police will contact you at ${r} if needed.</small>`;B.evidence_file&&(A+=`<br><strong>Evidence File:</strong> ${B.evidence_file}`),A+="</div>",v.innerHTML=A;try{e.reset()}catch(y){console.warn("Form reset failed:",y)}try{const y=document.getElementById("photoLocation");y&&(y.value="",y.removeAttribute("data-location"))}catch(y){console.warn("Photo location field reset failed:",y)}try{const y=document.getElementById("emergencyUserLocation");y&&(y.value="",y.removeAttribute("data-location"))}catch(y){console.warn("Emergency user location field reset failed:",y)}setTimeout(()=>{location.hash="#/my-complaints"},3e3)}catch(w){v.innerHTML=`<div class="alert alert-danger alert-dismissible">
      <strong><i class="bi bi-exclamation-triangle-fill"></i> Error:</strong> ${w.message}
    </div>`}}async function fe(e){const a=document.getElementById("updateStatus").value,t=document.getElementById("policeRemarks").value,i=document.getElementById("updateAlert"),o=new URLSearchParams(location.hash).get("id");try{if(!L)throw new Error("Database not available");const{error:s}=await L.from("complaints").update({status:a,police_remarks:t,assigned_to:n.id,updated_at:new Date().toISOString()}).eq("id",o);if(s)throw s;i.innerHTML='<div class="alert alert-success">Complaint updated successfully!</div>',setTimeout(()=>{location.hash="#/police-dashboard"},1500)}catch(s){i.innerHTML=`<div class="alert alert-danger">${s.message}</div>`}}async function he(e,a="",t=""){try{const i=await fetch("http://localhost:8080/get_complaints.php",{method:"GET",headers:{Accept:"application/json"},mode:"cors"});if(!i.ok)throw new Error("Failed to load complaints");const o=await i.json();if(!o.success)throw new Error(o.message||"Failed to load complaints");const s=o.complaints||[];if(!s||s.length===0){e.innerHTML='<div class="alert alert-info">No complaints found</div>';return}let l=s;g==="user"&&n&&n.id&&(l=s.filter(r=>r&&r.user_id===n.id)),a&&(l=l.filter(r=>r&&r.status===a)),t&&(l=l.filter(r=>r&&r.category===t)),g==="police"?j(l):q(l),R(l)}catch(i){console.error("Error loading complaints from PHP:",i),e.innerHTML=`<div class="alert alert-danger">Failed to load complaints: ${i.message}</div>`}}async function ye(){try{if(M(!0),L){const{error:e}=await L.auth.signOut();if(e)throw e}fetch("http://localhost:8080/logout.php",{method:"POST"}),n=null,g=null,F(),k("success","You have been successfully logged out."),setTimeout(()=>{window.location.hash="/"},1e3)}catch(e){console.error("Logout error:",e),k("error","Failed to log out. Please try again.")}finally{M(!1)}}window.logout=ye;async function O(){var i,o;if(!n)return;const e=g==="police"?document.getElementById("complaintsTableContainer"):document.getElementById("myComplaintsContainer");if(!e)return;const a=((i=document.getElementById("statusFilter"))==null?void 0:i.value)||"",t=((o=document.getElementById("categoryFilter"))==null?void 0:o.value)||"";try{if(!L){e.innerHTML='<div class="alert alert-info">Loading complaints from database...</div>',he(e,a,t);return}let s=L.from("complaints").select("*");g==="user"&&(s=s.eq("user_id",n.id)),a&&(s=s.eq("status",a)),t&&(s=s.eq("category",t)),s=s.order("created_at",{ascending:!1});const{data:l,error:r}=await s;if(r)throw r;if(!l||l.length===0){e.innerHTML='<div class="alert alert-info">No complaints found</div>';return}g==="police"?j(l):q(l),R(l)}catch(s){e.innerHTML=`<div class="alert alert-danger">${s.message}</div>`}}function R(e){const a=e.length,t=e.filter(u=>u.status==="resolved").length,i=e.filter(u=>u.status==="pending").length,o=e.filter(u=>u.status==="investigating").length,s=document.getElementById("totalComplaints"),l=document.getElementById("resolvedCount"),r=document.getElementById("pendingCount"),d=document.getElementById("investigatingCount"),b=document.getElementById("totalComplaints2"),v=document.getElementById("resolvedCount2");s&&(s.textContent=a),l&&(l.textContent=t),r&&(r.textContent=i),d&&(d.textContent=o),b&&(b.textContent=a),v&&(v.textContent=t)}function q(e){const a=document.getElementById("myComplaintsContainer");let t="";if(!e||e.length===0){a.innerHTML='<div class="alert alert-info">No complaints found</div>';return}e.forEach(i=>{const o=`badge-${i.status||"pending"}`,s=i.status==="investigating"?"Under Investigation":i.status?i.status.charAt(0).toUpperCase()+i.status.slice(1):"Pending";t+=`
      <div class="complaint-card ${i.status||"pending"}">
        <div class="d-flex justify-content-between align-items-start mb-2">
          <div>
            <h5 class="mb-1">${i.title||"Untitled Complaint"}</h5>
            <small class="text-muted">ID: ${i.complaint_id||"N/A"}</small>
          </div>
          <span class="badge ${o}">${s}</span>
        </div>
        <p class="mb-2"><strong>Category:</strong> ${i.category||"Not specified"}</p>
        <p class="mb-2"><strong>Date:</strong> ${i.created_at?new Date(i.created_at).toLocaleDateString():"Not specified"}</p>
        <p class="text-muted">${i.description?i.description.substring(0,100)+"...":"No description available"}</p>
        ${i.police_remarks?`<p class="mt-2 p-2 bg-light rounded"><strong>Police Remarks:</strong> ${i.police_remarks}</p>`:""}
        <button class="btn btn-sm btn-outline-primary mt-2" onclick="location.hash='#/view-complaint?id=${i.id||""}'">View Details</button>
      </div>
    `}),a.innerHTML=t}function j(e){const a=document.getElementById("complaintsTableContainer");if(!e||e.length===0){a.innerHTML='<div class="alert alert-info">No complaints found</div>';return}let t=`
    <div class="table-responsive">
      <table class="table table-hover">
        <thead>
          <tr>
            <th>Complaint ID</th>
            <th>Citizen</th>
            <th>Title</th>
            <th>Category</th>
            <th>Status</th>
            <th>Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
  `;e.forEach(i=>{const o=`badge-${i.status||"pending"}`,s=i.status==="investigating"?"Under Investigation":i.status?i.status.charAt(0).toUpperCase()+i.status.slice(1):"Pending";t+=`
      <tr>
        <td><strong>${i.complaint_id||"N/A"}</strong></td>
        <td>${i.user_id?i.user_id.substring(0,8)+"...":"Unknown"}</td>
        <td>${i.title||"Untitled"}</td>
        <td>${i.category||"Not specified"}</td>
        <td><span class="badge ${o}">${s}</span></td>
        <td>${i.created_at?new Date(i.created_at).toLocaleDateString():"Not specified"}</td>
        <td>
          <button class="btn btn-sm btn-primary" onclick="location.hash='#/view-complaint?id=${i.id||""}'">
            View
          </button>
          <button class="btn btn-sm btn-warning" onclick="location.hash='#/update-complaint?id=${i.id||""}'">
            Update
          </button>
        </td>
      </tr>
    `}),t+=`
        </tbody>
      </table>
    </div>
  `,a.innerHTML=t}window.loadComplaints=O;document.addEventListener("DOMContentLoaded",()=>{new MutationObserver(()=>{(document.getElementById("myComplaintsContainer")||document.getElementById("complaintsTableContainer"))&&O()}).observe(document.getElementById("page-content"),{childList:!0})});
